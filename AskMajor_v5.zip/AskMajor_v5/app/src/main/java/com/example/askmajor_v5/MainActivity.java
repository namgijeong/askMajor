package com.example.askmajor_v5;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;

import android.support.design.widget.NavigationView;



import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.widget.Button;
import android.widget.LinearLayout;


public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener{

    DrawerLayout drawer;
    Toolbar toolbar;

    SelectLoginMemberJoinFragment selectLoginMemberJoinFragment;
    MemberJoinFragment memberJoinFragment;
    UserProfileFragment userProfileFragment;
    UserProfileUpdateFragment userProfileUpdateFragment;

    PaintBoardFragment paintBoardFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        setContentView(R.layout.activity_main);
        //툴바를 액션바로 지정
        toolbar=findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        //app name 디폴트로 나오는것 없애기
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        //draw에 리스너를 설정
        drawer=findViewById(R.id.drawer_layout);

        ActionBarDrawerToggle toggle= new ActionBarDrawerToggle(
                this,drawer,toolbar,R.string.navigation_drawer_open,R.string.navigation_drawer_close
        );
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        //네비게이션뷰에 리스너를 설정
        NavigationView navigationView=findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);


        selectLoginMemberJoinFragment=new SelectLoginMemberJoinFragment();
        memberJoinFragment= new MemberJoinFragment();
        userProfileFragment=new UserProfileFragment();
        userProfileUpdateFragment= new UserProfileUpdateFragment();
        paintBoardFragment=new PaintBoardFragment();

        //디폴트 프래그먼트->첫화면
        getSupportFragmentManager().beginTransaction().replace(R.id.main_container, paintBoardFragment).commit();



    }

    //툴바 메뉴 올리기(이걸 써야지만 레이아웃상 올려짐)
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater ().inflate (R.menu.toolbar_menu, menu);

        return true;
    }
    //툴바메뉴가 선택되었을때
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        return true;
    }

    //네비게이션 뷰 아이템이 선택되었을때
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

        int id=menuItem.getItemId();

        if(id==R.id.nav_home){
            onFragmentChanged(R.layout.fragment_select_login_memberjoin);
        }
        else if(id==R.id.nav_profile){
            onFragmentChanged(R.layout.fragment_user_profile);
        }

        return true;
    }

    //프래그먼트 바꿔주기 기능
    public void onFragmentChanged(int index){
        if(index==R.layout.fragment_member_join){
            getSupportFragmentManager().beginTransaction().replace(R.id.main_container,memberJoinFragment).commit();
        }
        else if(index==R.layout.fragment_select_login_memberjoin){
            getSupportFragmentManager().beginTransaction().replace(R.id.main_container,selectLoginMemberJoinFragment).commit();
        }
        else if(index==R.layout.fragment_user_profile){
            getSupportFragmentManager().beginTransaction().replace(R.id.main_container,userProfileFragment).commit();
        }
        else if(index==R.layout.fragment_user_profile_update){
            getSupportFragmentManager().beginTransaction().replace(R.id.main_container,userProfileUpdateFragment).commit();
        }
    }
}