package com.example.askmajor_v5;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;

import android.support.design.widget.NavigationView;



import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.widget.Button;
import android.widget.Toast;




public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener{

    DrawerLayout drawer;
    Toolbar toolbar;

    SelectLoginMemberjoinFragment selectLoginMemberjoinFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        setContentView(R.layout.activity_main);

        toolbar=findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        //app name 디폴트로 나오는것 없애기
        getSupportActionBar().setDisplayShowTitleEnabled(false);

        drawer=findViewById(R.id.drawer_layout);

        ActionBarDrawerToggle toggle= new ActionBarDrawerToggle(
                this,drawer,toolbar,R.string.navigation_drawer_open,R.string.navigation_drawer_close
        );
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView=findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);


        selectLoginMemberjoinFragment=new SelectLoginMemberjoinFragment();
        getSupportFragmentManager().beginTransaction().add(R.id.main_container,selectLoginMemberjoinFragment).commit();



    }

    //툴바 메뉴 올리기(이걸 써야지만 레이아웃상 올려짐)
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater ().inflate (R.menu.toolbar_menu, menu);

        return true;
    }
    //툴바메뉴가 선택되었을때
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        return true;
    }

    //네비게이션 뷰 아이템이 선택되었을때
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        return false;
    }
}