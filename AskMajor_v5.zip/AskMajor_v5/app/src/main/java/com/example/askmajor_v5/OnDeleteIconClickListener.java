package com.example.askmajor_v5;

import android.view.View;

public interface OnDeleteIconClickListener {

    public void onDeleteIconClick(DynamicImageViewAdapter.ViewHolder holder, View view, int position);
}
