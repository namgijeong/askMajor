package com.example.askmajor_v5.ui;

import android.content.ContentResolver;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.example.askmajor_v5.MainActivity;
import com.example.askmajor_v5.R;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

public class DynamicImageViewAdapter extends RecyclerView.Adapter<DynamicImageViewAdapter.ViewHolder>{
    static String tag="DynamicImageViewAdapter";
    //갤러리에서 가져온 여러 이미지들 주소를 저장하는 리스트->질문글을 올릴때 첨부하는 이미지들
    ArrayList<Uri> items= new ArrayList<Uri>(30);

    //Activity에서 가져온 context를 사용해야함->mainActivity에서
    //Non-static field 'context' cannot be referenced from a static context 에러
    //static으로 설정
    static Context context;
    static MainActivity mainActivity;

    static ViewHolder oneViewHolder;
    public DynamicImageViewAdapter(Context context){
        this.context=context;
        mainActivity=(MainActivity)context;
    }

    static class ViewHolder extends RecyclerView.ViewHolder{

        ImageView imageView;
        public int getViewWidth(){
            return (int)imageView.getWidth();
        }
        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            imageView=itemView.findViewById(R.id.imageView_takeWriteQuestionImage);
        }

        public void setItem(Uri fileUri){
            Bitmap resizedImgBitmap=decodeWriteQuestionImage(fileUri);
            if(resizedImgBitmap!=null){
                imageView.setImageBitmap(resizedImgBitmap);
            }

        }
    }
    //non-static method cannot be referenced from a static context 에러
    //static 메소드가 아닌 메소드는 static context 안에서 참조될 수 없다.->static을 붙여줘야함.
    public static Bitmap decodeWriteQuestionImage(Uri fileUri){
        ContentResolver resolver= mainActivity.getContentResolver();

        try{
            InputStream intstream = resolver.openInputStream(fileUri);
            Bitmap imgBitmap= BitmapFactory.decodeStream(intstream);
            //어짜피 이미지뷰에 맞게 비트맵이 그려져서 굳이 크기 줄일 필요없다.
            //하지만 원본비율에 맞추는게 필요하다.
            Bitmap resizedImgBitmap;
            //이 공식대로 하면 원본 이미지가 이미지뷰안에 완전히 들어오면서 엄청 작게 보이기 때문에 안된다.
            /*int viewWidth=oneViewHolder.getViewWidth();
            int srcWidth= imgBitmap.getWidth();
            float ratio=(float)viewWidth/(float)srcWidth;
            float height=imgBitmap.getHeight()*ratio;*/
            int viewWidth=600;
            int srcWidth= imgBitmap.getWidth();
            float ratio=(float)viewWidth/(float)srcWidth;
            float height=imgBitmap.getHeight()*ratio;
            resizedImgBitmap=Bitmap.createScaledBitmap(imgBitmap, viewWidth, (int)height, false);
            //resizedImgBitmap=imgBitmap;

            intstream.close();

            return resizedImgBitmap;

        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        //context=viewGroup.getContext();
        //인터넷에 검색해서 예제를 보니까 그냥 viewGroup에서 context를 가져오더라..
        LayoutInflater inflater= LayoutInflater.from(viewGroup.getContext());
        //LayoutInflater inflater= LayoutInflater.from(context);
        View itemView= inflater.inflate(R.layout.write_question_image_item,viewGroup,false);
        oneViewHolder=new ViewHolder(itemView);
        return oneViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {
        //i는 position
        Uri item=items.get(i);
        viewHolder.setItem(item);
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    public void addItem(Uri item){
        items.add(item);
    }

    public void setItems(ArrayList<Uri> items){
        this.items=items;
    }

    public Uri getItem(int position){
        return items.get(position);
    }

    public void setItem(int position, Uri item){
        items.set(position,item);
    }
}
