package com.example.askmajor_v5;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;


public class SelectLoginMemberJoinFragment extends Fragment {



    //activity에 추가할때 호출되어 액티비티를 받아오기 위해
    Context context;
    MainActivity mainActivity;
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.context=context;
        mainActivity = (MainActivity) context;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View selectLoginMemberJoinFragment= inflater.inflate(R.layout.fragment_select_login_memberjoin, container, false);

        //스스로 자기자신이 inflate한 다음에 내부 요소 참조-fragment는 activity와 다름
        Button goMemberJoin=selectLoginMemberJoinFragment.findViewById(R.id.go_memberJoin_button);
        //이버튼을 누르면 액티비티에서 프래그먼트를 바꿔준다->회원가입 프래그먼트로
        goMemberJoin.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                //이거는 만약 프래그먼트가 현재 액티비티에 올라와져있는 상태가 아니면 에러난다
                //MainActivity mainActivity=(MainActivity) getActivity();

                mainActivity.onFragmentChanged(R.layout.fragment_member_join);
            }
        });




        return selectLoginMemberJoinFragment;
    }
}