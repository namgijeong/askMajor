package com.example.askmajor_v5;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;

public class PaintBoard extends View {

    public boolean changed=false;
    Canvas mCanvas;
    Bitmap mBitmap;
    Paint mPaint;
    float lastX;
    float lastY;
    Path mPath=new Path();
    float mCurveEndX;
    float mCurveEndY;
    int mInvalidateExtraBorder=10;

    static final float TOUCH_TOLERANCE=8;
    public PaintBoard(Context context) {
        super(context);
        init(context);
    }

    public PaintBoard(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }
    public void setStrokeWidth(float progress){
        mPaint.setStrokeWidth(progress);
    }
    //Color.Black이 int형
    public void setColor(int selected){
        mPaint.setColor(selected);
    }
    private void init(Context context){
        mPaint=new Paint();
        //부드러운 선
        mPaint.setAntiAlias(true);
        mPaint.setColor(Color.BLACK);
        mPaint.setStyle(Paint.Style.STROKE);
        //stroke의 꼭짓점 부분에 사용되는 연결 모양을 설정
        mPaint.setStrokeJoin(Paint.Join.ROUND);
        //stroke의 시작과 끝 부분의 모양을 설정
        mPaint.setStrokeCap(Paint.Cap.ROUND);
        //stroke의 폭
        mPaint.setStrokeWidth(3.0F);
        
        this.lastX=-1;
        this.lastY=-1;
    }

    //화면의 사이즈가 변하거나, 초기 액티비티가 생성될 때 호출
    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh){
        Bitmap img=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);
        //비트맵에 캔버스를 올리고
        Canvas canvas=new Canvas();
        canvas.setBitmap(img);

        //비트맵에 올린 캔버스에 미리 그린다.
        //drawColor은 캔버스에 한가지 색으로 칠한다.
        canvas.drawColor(Color.WHITE);

        mBitmap=img;
        mCanvas=canvas;

    }

    //화면의 사이즈가 변하거나 초기 액티비티가 생성될때 호출
    @Override
    protected void onDraw(Canvas canvas){
        if(mBitmap!=null){
            //이 비트맵 가지고 이 위치에서 그린다. paint객체를 가지고
            canvas.drawBitmap(mBitmap,0,0,null);
        }
    }

    private Rect touchDown(MotionEvent event){
        float x=event.getX();
        float y=event.getY();

        lastX=x;
        lastY=y;

        Rect mInvalidRect=new Rect();
        //기준점을 x,y로 이동
        mPath.moveTo(x,y);

        final int border=mInvalidateExtraBorder;
        mInvalidRect.set((int)x-border,(int)y-border,(int)x+border,(int)y+border);
        mCurveEndX=x;
        mCurveEndY=y;
        //비트맵에 올린 캔버스에 미리 선을 그린다.
        mCanvas.drawPath(mPath,mPaint);

        return mInvalidRect;
    }

    private Rect touchMove(MotionEvent event){
        Rect rect=processMove(event);
        return rect;
    }
    public Rect touchUp(MotionEvent event, boolean cancel){
        Rect rect=processMove(event);
        return rect;
    }

    private Rect processMove(MotionEvent event){
        final float x=event.getX();
        final float y=event.getY();

        final float dx=Math.abs(x-lastX);
        final float dy=Math.abs(y-lastY);

        Rect mInvalidRect= new Rect();
        //일정이상 거리를 이동하면
        if(dx>=TOUCH_TOLERANCE||dy>=TOUCH_TOLERANCE){
            final int border=mInvalidateExtraBorder;
            mInvalidRect.set((int)mCurveEndX-border,(int)mCurveEndY-border,(int)mCurveEndX+border,(int)mCurveEndY+border);
            //중간지점
            float cX=mCurveEndX=(x+lastX)/2;
            float cY=mCurveEndY=(y+lastY)/2;

            //점에서 점까지 곡선을 그린다
            mPath.quadTo(lastX,lastY,cX,cY);

            //union 범위 병합
            mInvalidRect.union((int)lastX-border,(int)lastY-border,(int)lastX+border,(int)lastY+border);
            mInvalidRect.union((int)cX-border,(int)cY-border,(int)cX+border,(int)cY+border);

            //최근 좌표 갱신
            lastX=x;
            lastY=y;

            //비트맵에 올린 캔버스에 미리 선을 그린다.
            mCanvas.drawPath(mPath,mPaint);
        }
        return mInvalidRect;

    }
    //터치될때마다 호출
    @Override
    public boolean onTouchEvent(MotionEvent event){
        int action=event.getAction();
        switch(action){
            case MotionEvent.ACTION_UP:
                changed=true;
                
                //사각형에 해당하는 범위를 지정하여 해당 부분만 화면을 갱신할 때 사용
                Rect rect= touchUp(event,false);
                if(rect !=null){

                    //rect 영역 객체만큼 다시 그린다.
                    //onDraw 호출
                    invalidate(rect);
                }
                //라인,커브는 지우고 내부 정보는 다시 사용
                mPath.rewind();
                return true;

            case MotionEvent.ACTION_DOWN:
                rect=touchDown(event);
                if(rect!=null){
                    invalidate(rect);
                }
                return true;

            case MotionEvent.ACTION_MOVE:
                rect=touchMove(event);
                if(rect!=null){
                    invalidate(rect);
                }
                return true;


        }

        return false;
    }
}
