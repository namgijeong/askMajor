package com.example.askmajor_v5;

import android.content.ContentResolver;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class DynamicImageViewAdapter extends RecyclerView.Adapter<DynamicImageViewAdapter.ViewHolder>
            implements OnDeleteIconClickListener{
    static String tag="DynamicImageViewAdapter";
    //갤러리에서 가져온 여러 이미지들 주소를 저장하는 리스트->질문글을 올릴때 첨부하는 이미지들
    ArrayList<Uri> items= new ArrayList<Uri>(30);

    //외부에서 가져온 리스너
    OnDeleteIconClickListener onDeleteIconClickListener;

    //Activity에서 가져온 context를 사용해야함->mainActivity에서
    //Non-static field 'context' cannot be referenced from a static context 에러
    //static으로 설정
    static Context context;
    static MainActivity mainActivity;

    static ViewHolder oneViewHolder;
    
    //외부에서 가져온 리스너-> 리스너 코드를 할때 어댑터의 아이템 정보를 지워야하기 때문에(이미지 없애기)어댑터 객체 접근-> 그래서 외부에서 리스너 코드를 써야하기때문
    //어댑터 객체 밖에서 리스너를 설정하고 설정된 리스너 쪽으로 이벤트를 전달받도록
    public DynamicImageViewAdapter(Context context){
        this.context=context;
        mainActivity=(MainActivity)context;
    }

    public void setOnDeleteIconClickListener(OnDeleteIconClickListener listener){
        this.onDeleteIconClickListener=listener;
    }
    @Override
    public void onDeleteIconClick(ViewHolder holder, View view,int position) {
        if(onDeleteIconClickListener!=null){
            //adapter객체 바깥 리스너로 일 전달
            //onDeleteIconClickListener는 받은 객체 바깥의 리스너!!
            onDeleteIconClickListener.onDeleteIconClick(holder,view,position);
        }
    }

    static class ViewHolder extends RecyclerView.ViewHolder{

        ImageView imageView;
        Button button;
        public int getViewWidth(){
            return (int)imageView.getWidth();
        }
        public ViewHolder(@NonNull View itemView, final OnDeleteIconClickListener listener) {
            super(itemView);

            imageView=itemView.findViewById(R.id.imageView_takeWriteQuestionImage);
            button=itemView.findViewById(R.id.button_takeWriteQuestionImage_delete);
            
            button.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {
                    //이 뷰홀더에 표시할 아이템이 어댑터에서 몇 번째인지 정보를 반환
                    int position=getAdapterPosition();

                    //부르는것:어댑터 객체 리스너 호출-> 그리고 어댑터의 외부 리스너 호출이 진행
                    if(listener!=null){
                        //뷰 홀더 자기자신
                        listener.onDeleteIconClick(ViewHolder.this,v,position);
                    }
                }
            });
            
            
        }

        public void setItem(Uri fileUri){
            Bitmap resizedImgBitmap=decodeWriteQuestionImage(fileUri);
            if(resizedImgBitmap!=null){
                imageView.setImageBitmap(resizedImgBitmap);
            }

        }
    }
    //non-static method cannot be referenced from a static context 에러
    //static 메소드가 아닌 메소드는 static context 안에서 참조될 수 없다.->static을 붙여줘야함.
    public static Bitmap decodeWriteQuestionImage(Uri fileUri){
        ContentResolver resolver= mainActivity.getContentResolver();

        try{
            InputStream intstream = resolver.openInputStream(fileUri);
            Bitmap imgBitmap= BitmapFactory.decodeStream(intstream);
            //어짜피 이미지뷰에 맞게 비트맵이 그려져서 굳이 크기 줄일 필요없다.
            //하지만 원본비율에 맞추는게 필요하다.
            Bitmap resizedImgBitmap;
            //이 공식대로 하면 원본 이미지가 이미지뷰안에 완전히 들어오면서 엄청 작게 보이기 때문에 안된다.
            /*int viewWidth=oneViewHolder.getViewWidth();
            int srcWidth= imgBitmap.getWidth();
            float ratio=(float)viewWidth/(float)srcWidth;
            float height=imgBitmap.getHeight()*ratio;*/
            int viewWidth=600;
            int srcWidth= imgBitmap.getWidth();
            float ratio=(float)viewWidth/(float)srcWidth;
            float height=imgBitmap.getHeight()*ratio;
            resizedImgBitmap=Bitmap.createScaledBitmap(imgBitmap, viewWidth, (int)height, false);


            intstream.close();

            return resizedImgBitmap;

        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    //뷰 홀더 생성할때 자동으로 실행하는 메소드
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        //context=viewGroup.getContext();
        //인터넷에 검색해서 예제를 보니까 그냥 viewGroup에서 context를 가져오더라..
        LayoutInflater inflater= LayoutInflater.from(viewGroup.getContext());
        //LayoutInflater inflater= LayoutInflater.from(context);
        View itemView= inflater.inflate(R.layout.write_question_image_item,viewGroup,false);
        //어댑터 자기자신이 리스너객체를 구현받으므로
        oneViewHolder=new ViewHolder(itemView,this);
        return oneViewHolder;
    }

    //뷰 홀더가 재사용될때 자동으로 실행하는 메소드
    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {
        //i는 position
        Uri item=items.get(i);
        viewHolder.setItem(item);
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    public void addItem(Uri item){
        items.add(item);
    }

    public void setItems(ArrayList<Uri> items){
        this.items=items;
    }

    public Uri getItem(int position){
        return items.get(position);
    }

    public void setItem(int position, Uri item){
        items.set(position,item);
    }
    
    //arraylist 데이터 초기화
    public void removeItems(){
        //이렇게하면 맨처음에 이 앱을 딱킬때 items.size()가
        int size=getItemCount();
        int start=0;
        while(start<=size-1){
            //아.. 맨앞에것을 한번 remove 지우면 인덱스가 다시 0부터 n-1까지 된다. 그래서 인덱스를 증가하면서 remove하면 안된다
            items.remove(0);
            start++;
        }


    }
    //원하는 인덱스 아이템 지우기
    public void removeItem(int position){
        items.remove(position);
    }
}
