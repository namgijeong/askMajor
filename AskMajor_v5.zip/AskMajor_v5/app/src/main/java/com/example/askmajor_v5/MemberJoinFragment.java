package com.example.askmajor_v5;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;


public class MemberJoinFragment extends Fragment {

    //스피너 아이템 목록
    String[] spinnerItems={"대학원생","학부생","예비전공생","현업종사자-비전공자","현업종사자-전공자","교수"};
    String selectedSpinnerItems;
    //activity에 추가할때 호출되어 액티비티를 받아오기 위해
    Context context;
    MainActivity mainActivity;
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.context=context;
        mainActivity = (MainActivity) context;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v= inflater.inflate(R.layout.fragment_member_join, container, false);

        //fragment는 inflate한후 내부 뷰들을 참조할수있다.
        Spinner spinner=v.findViewById(R.id.memberJoin_spinnerCurrentJob);

        ArrayAdapter<String> currentJobAdapter = new ArrayAdapter<String>(
                context,android.R.layout.simple_spinner_item,spinnerItems
        );

        currentJobAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spinner.setAdapter(currentJobAdapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedSpinnerItems=spinnerItems[position];
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        //취소버튼 누를시 로그인선택화면 프래그먼트로 이동
        Button goCancelButton=v.findViewById(R.id.go_joinCancel_button);
        goCancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mainActivity.onFragmentChanged(R.layout.fragment_select_login_memberjoin);
            }
        });



        return v;
    }
}