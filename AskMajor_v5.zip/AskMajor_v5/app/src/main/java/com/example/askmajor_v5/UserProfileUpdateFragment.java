package com.example.askmajor_v5;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;


public class UserProfileUpdateFragment extends Fragment {

    //스피너 아이템 목록
    String[] spinnerItems={"대학원생","학부생","예비전공생","현업종사자-비전공자","현업종사자-전공자","교수"};
    String selectedSpinnerItems;
    //activity에 추가할때 호출되어 액티비티를 받아오기 위해
    Context context;
    MainActivity mainActivity;
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.context=context;
        mainActivity = (MainActivity) context;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v= inflater.inflate(R.layout.fragment_user_profile_update, container, false);
        Spinner spinner= v.findViewById(R.id.user_profile_update_spinnerCurrentJob);

        ArrayAdapter<String> currentJobAdapter = new ArrayAdapter<String>(
                context,android.R.layout.simple_spinner_item,spinnerItems
        );

        currentJobAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spinner.setAdapter(currentJobAdapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedSpinnerItems=spinnerItems[position];
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        //취소 버튼을 누르면 회원 정보 프래그먼트로 이동
        Button cancel_goUserProfile =v.findViewById(R.id.user_profile_update_buttonCancel);
        cancel_goUserProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mainActivity.onFragmentChanged(R.layout.fragment_user_profile);
            }
        });

        return v;
    }
}