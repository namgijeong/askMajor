package com.example.askmajor_v5;

import android.content.ContentResolver;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;


public class WriteQuestionFragment extends Fragment {

    //스피너 아이템 목록
    String[] spinnerItems = {"빨강", "초록", "파랑", "검정", "노랑", "자홍색"};
    String selectedSpinnerItems;
    //activity에 추가할때 호출되어 액티비티를 받아오기 위해
    Context context;
    MainActivity mainActivity;

    //inflate한 전체뷰
    View rootView;

    //갤러리에서 가져온 이미지 표시하는 위치
    ImageView attachImage;
    public WriteQuestionFragment() {
        // Required empty public constructor
    }


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.context = context;
        mainActivity = (MainActivity) context;
    }

    @Override
    public void onDetach() {
        super.onDetach();
        //이렇게하는건 작동안된다
        //container.removeView(paintBoard);
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        rootView=inflater.inflate(R.layout.fragment_write_question, container, false);
        return rootView;
    }

    @Override
    public void onViewCreated(final View view, Bundle savedInstanceState){
        Button goPaintBoardFragment = rootView.findViewById(R.id.button_goPaintBoardFragment);
        goPaintBoardFragment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mainActivity.onFragmentChanged(R.layout.fragment_paint_board);
            }
        });

        Button goMyGalleryQuestionImage =rootView.findViewById(R.id.button_goMyGalleryQuestionImage);
        goMyGalleryQuestionImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mainActivity.openGallery();
            }
        });

        attachImage= rootView.findViewById(R.id.imageView_attachImage);
    }

    public void decodeWriteQuestionImage(Uri fileUri){
        ContentResolver resolver= mainActivity.getContentResolver();

        try{
            InputStream intstream = resolver.openInputStream(fileUri);
            Bitmap imgBitmap= BitmapFactory.decodeStream(intstream);
            attachImage.setImageBitmap(imgBitmap);
            intstream.close();
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }


}