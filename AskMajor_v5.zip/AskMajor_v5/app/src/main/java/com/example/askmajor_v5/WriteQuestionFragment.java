package com.example.askmajor_v5;

import android.content.Context;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;


public class WriteQuestionFragment extends Fragment {

    //스피너 아이템 목록
    String[] spinnerItems = {"건축", "교통,운송", "기계,금속", "산업", "소재,재료", "전기,전자","정밀,에너지","컴퓨터,통신","토목,도시","화공","기타 공학",
        "교육일반","유아교육","중등교육","초등교육","특수교육",
            "경영,경제","법률","사회과학",
            "디자인","무용,체육","미술,조형","연극,영화","음악","응용예술",
            "간호","약학","의료","치료,보건",
            "언어,문학","인문과학",
            "농림,수산","생물,화학,환경","생활과학","수학,물리,천문,지리"
    };
    String selectedSpinnerItems;
    //activity에 추가할때 호출되어 액티비티를 받아오기 위해
    Context context;
    MainActivity mainActivity;

    //inflate한 전체뷰
    View rootView;

    //갤러리에서 가져온 이미지 표시하는 위치
    RecyclerView attachImage;

    //이미지들을 표시해줄 recyclerview의 adapter
    DynamicImageViewAdapter dynamicImageViewAdapter;


    public WriteQuestionFragment() {
        // Required empty public constructor
    }


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.context = context;
        mainActivity = (MainActivity) context;
        //위에서 선언하면 생성자 호출전이므로 adpter에 들어가는 context가 null이다.
        dynamicImageViewAdapter= new DynamicImageViewAdapter(context);
    }

    @Override
    public void onDetach() {
        super.onDetach();

    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        rootView=inflater.inflate(R.layout.fragment_write_question, container, false);



        return rootView;
    }

    @Override
    public void onViewCreated(final View view, Bundle savedInstanceState){
        Button goPaintBoardFragment = rootView.findViewById(R.id.button_goPaintBoardFragment);
        goPaintBoardFragment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mainActivity.onFragmentChanged(R.layout.fragment_paint_board);
            }
        });

        Button goMyGalleryQuestionImage =rootView.findViewById(R.id.button_goMyGalleryQuestionImage);
        goMyGalleryQuestionImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mainActivity.openGallery();
            }
        });



        //recycler view 설정
        attachImage= rootView.findViewById(R.id.recyclerView_attachWriteQuestionImages);

        //recycler view 가 보이는 모양 설정
        //view가 생성된 이후(onViewCreated)에 불러와서 설정하는것이 안전하다
        GridLayoutManager layoutManager = new GridLayoutManager(context,3);
        attachImage.setLayoutManager(layoutManager);
        //데이터 초기화 한 후 어댑터 붙이기!!
        //adpater에 아이템을 추가한후 setAdapter를 해야지만 바로바로 갤러리 이미지 누른게 이미지뷰에 붙여져서 반영이 된다!!
        dynamicImageViewAdapter.removeItems();
        attachImage.setAdapter(dynamicImageViewAdapter);
        //외부 리스너 설정
        dynamicImageViewAdapter.setOnDeleteIconClickListener(new OnDeleteIconClickListener() {
            @Override
            public void onDeleteIconClick(DynamicImageViewAdapter.ViewHolder holder, View view, int position) {
                dynamicImageViewAdapter.removeItem(position);
                //adpater에 아이템을 지운후 setAdapter를 해야지만 바로바로 갤러리 이미지 누른게 이미지뷰에 붙여져서 반영이 된다!!
                attachImage.setAdapter(dynamicImageViewAdapter);

            }
        });




        Spinner spinnerRelatedMajor1 = rootView.findViewById(R.id.spinner_relatedMajor1);
        Spinner spinnerRelatedMajor2 = rootView.findViewById(R.id.spinner_relatedMajor2);
        Spinner spinnerRelatedMajor3 = rootView.findViewById(R.id.spinner_relatedMajor3);

        ArrayAdapter<String> adapterRelatedMajor = new ArrayAdapter<String>(
                context, android.R.layout.simple_spinner_item, spinnerItems
        );

        adapterRelatedMajor.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spinnerRelatedMajor1.setAdapter(adapterRelatedMajor);

        spinnerRelatedMajor1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedSpinnerItems = spinnerItems[position];

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        spinnerRelatedMajor2.setAdapter(adapterRelatedMajor);

        spinnerRelatedMajor2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedSpinnerItems = spinnerItems[position];

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        spinnerRelatedMajor3.setAdapter(adapterRelatedMajor);

        spinnerRelatedMajor3.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedSpinnerItems = spinnerItems[position];

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


    }

    public void getUriWriteQuestionImage(Uri fileUri){

        dynamicImageViewAdapter.addItem(fileUri);
        //adpater에 아이템을 추가한후 setAdapter를 해야지만 바로바로 갤러리 이미지 누른게 이미지뷰에 붙여져서 반영이 된다!!
        //다시 그리기 함수 소용없었음. 아래는 내가 시도해본것
        //rootView.invalidate();
        //attachImage.invalidate();
        attachImage.setAdapter(dynamicImageViewAdapter);

    }




}