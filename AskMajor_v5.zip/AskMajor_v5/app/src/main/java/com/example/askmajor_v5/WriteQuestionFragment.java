package com.example.askmajor_v5;

import android.content.ContentResolver;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.example.askmajor_v5.ui.DynamicImageViewAdapter;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;


public class WriteQuestionFragment extends Fragment {


    //activity에 추가할때 호출되어 액티비티를 받아오기 위해
    Context context;
    MainActivity mainActivity;

    //inflate한 전체뷰
    View rootView;

    //갤러리에서 가져온 이미지 표시하는 위치
    RecyclerView attachImage;

    //이미지들을 표시해줄 recyclerview의 adapter
    DynamicImageViewAdapter dynamicImageViewAdapter;


    public WriteQuestionFragment() {
        // Required empty public constructor
    }


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.context = context;
        mainActivity = (MainActivity) context;
        //위에서 선언하면 생성자 호출전이므로 adpter에 들어가는 context가 null이다.
        dynamicImageViewAdapter= new DynamicImageViewAdapter(context);
    }

    @Override
    public void onDetach() {
        super.onDetach();

    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        rootView=inflater.inflate(R.layout.fragment_write_question, container, false);



        return rootView;
    }

    @Override
    public void onViewCreated(final View view, Bundle savedInstanceState){
        Button goPaintBoardFragment = rootView.findViewById(R.id.button_goPaintBoardFragment);
        goPaintBoardFragment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mainActivity.onFragmentChanged(R.layout.fragment_paint_board);
            }
        });

        Button goMyGalleryQuestionImage =rootView.findViewById(R.id.button_goMyGalleryQuestionImage);
        goMyGalleryQuestionImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mainActivity.openGallery();
            }
        });
        
        //recycler view 설정
        attachImage= rootView.findViewById(R.id.recyclerView_attachWriteQuestionImages);

        //recycler view 가 보이는 모양 설정
        //view가 생성된 이후(onViewCreated)에 불러와서 설정하는것이 안전하다
        GridLayoutManager layoutManager = new GridLayoutManager(context,3);
        attachImage.setLayoutManager(layoutManager);
        //attachImage.setAdapter(dynamicImageViewAdapter);

    }

    public void getUriWriteQuestionImage(Uri fileUri){

        dynamicImageViewAdapter.addItem(fileUri);
        //adpater에 아이템을 추가한후 setAdapter를 해야지만 바로바로 갤러리 이미지 누른게 이미지뷰에 붙여져서 반영이 된다!!
        //다시 그리기 함수 소용없었음. 아래는 내가 시도해본것
        //rootView.invalidate();
        //attachImage.invalidate();
        attachImage.setAdapter(dynamicImageViewAdapter);

    }




}