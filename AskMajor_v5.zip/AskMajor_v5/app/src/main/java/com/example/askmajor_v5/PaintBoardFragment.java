package com.example.askmajor_v5;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;


public class PaintBoardFragment extends Fragment {

    //activity에 추가할때 호출되어 액티비티를 받아오기 위해
    Context context;
    MainActivity mainActivity;

    //프래그먼트 위에 올려줄 뷰
    PaintBoard paintBoard;

    //프래그먼트 위에 올려줄 뷰가 붙여질 위치를 정해주기 위한 뷰
    LinearLayout attachPaintBoard;

    //프래그먼트가 붙여질 부모 뷰 -> viewgroup container
    ViewGroup container;
  public PaintBoardFragment() {
        // Required empty public constructor
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.context=context;
        mainActivity = (MainActivity) context;
    }

    @Override
    public void onDetach() {
        super.onDetach();
        //이렇게하는건 작동안된다
        //container.removeView(paintBoard);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView=inflater.inflate(R.layout.fragment_paint_board, container, false);
        attachPaintBoard= rootView.findViewById(R.id.attchLayoutPaintBoard);

        paintBoard=new PaintBoard(context);

        attachPaintBoard.addView(paintBoard);

        //프래그먼트가 붙여질 부모 뷰 -> viewgroup container
        //이렇게하는건 작동안된다
        //this.container=container;
        //container.addView(paintBoard);


        return rootView;
    }

    @Override
    public void onViewCreated(final View view, Bundle savedInstanceState){
        //attachPaintBoard.addView(paintBoard);
    }

}