package com.example.askmajor_v5;

import android.Manifest;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;


public class PaintBoardFragment extends Fragment {

    //스피너 아이템 목록
    String[] spinnerItems = {"빨강", "초록", "파랑", "검정", "노랑", "자홍색"};
    String selectedSpinnerItems;
    //activity에 추가할때 호출되어 액티비티를 받아오기 위해
    Context context;
    MainActivity mainActivity;

    //inflate한 전체뷰
    View rootView;
    //프래그먼트 위에 올려줄 뷰
    PaintBoard paintBoard;

    //프래그먼트 위에 올려줄 뷰가 붙여질 위치를 정해주기 위한 뷰
    LinearLayout attachPaintBoard;

    //최근에 선택한 색깔을 저장하는 변수
    int currentColor;

    //Paintboard에서 그린 비트맵
    Bitmap drawBitmap;

    //프래그먼트가 붙여질 부모 뷰 -> viewgroup container
    //ViewGroup container;


    public PaintBoardFragment() {
        // Required empty public constructor
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.context = context;
        mainActivity = (MainActivity) context;
    }

    @Override
    public void onDetach() {
        super.onDetach();
        //이렇게하는건 작동안된다
        //container.removeView(paintBoard);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        rootView = inflater.inflate(R.layout.fragment_paint_board, container, false);
        attachPaintBoard = rootView.findViewById(R.id.attchLayoutPaintBoard);

        paintBoard = new PaintBoard(context);

        attachPaintBoard.addView(paintBoard);

        //프래그먼트가 붙여질 부모 뷰 -> viewgroup container
        //이렇게하는건 작동안된다
        //this.container=container;
        //container.addView(paintBoard);


        return rootView;
    }

    @Override
    public void onViewCreated(final View view, Bundle savedInstanceState) {

        SeekBar seekBarLineWidth = rootView.findViewById(R.id.seekBarLineWidth);
        TextView textLineWidthValue = rootView.findViewById(R.id.textLineWidthValue);
        seekBarLineWidth.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                textLineWidthValue.setText("" + progress);
                paintBoard.setStrokeWidth((float) progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        Spinner spinnerLineColor = rootView.findViewById(R.id.spinnerLineColorSelect);

        ArrayAdapter<String> currentJobAdapter = new ArrayAdapter<String>(
                context, android.R.layout.simple_spinner_item, spinnerItems
        );

        currentJobAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spinnerLineColor.setAdapter(currentJobAdapter);

        spinnerLineColor.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedSpinnerItems = spinnerItems[position];
                if (selectedSpinnerItems.equals("빨강")) {
                    //Color.Black이 int형
                    paintBoard.setColor(Color.RED);
                    currentColor=Color.RED;
                } else if (selectedSpinnerItems.equals("초록")) {
                    //Color.Black이 int형
                    paintBoard.setColor(Color.GREEN);
                    currentColor=Color.GREEN;
                } else if (selectedSpinnerItems.equals("파랑")) {
                    //Color.Black이 int형
                    paintBoard.setColor(Color.BLUE);
                    currentColor=Color.BLUE;
                } else if (selectedSpinnerItems.equals("검정")) {
                    //Color.Black이 int형
                    paintBoard.setColor(Color.BLACK);
                    currentColor=Color.BLACK;
                } else if (selectedSpinnerItems.equals("노랑")) {
                    //Color.Black이 int형
                    paintBoard.setColor(Color.YELLOW);
                    currentColor=Color.YELLOW;
                } else if (selectedSpinnerItems.equals("자홍색")) {
                    //Color.Black이 int형
                    paintBoard.setColor(Color.MAGENTA);
                    currentColor=Color.MAGENTA;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        // Get the ScrollView
        /*final ScrollView totalPaintBoardScrollView = (ScrollView) rootView.findViewById(R.id.totalPaintBoardScrollView);
        Button buttonPaintBoardScrollState=rootView.findViewById(R.id.buttonPaintBoardScrollState);
        final int[] flag = {0};
        
        buttonPaintBoardScrollState.setOnTouchListener(new View.OnTouchListener(){

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(flag[0] ==0){
                    // Disable Scrolling by setting up an OnTouchListener to do nothing
                    totalPaintBoardScrollView.setOnTouchListener( new View.OnTouchListener(){
                        @Override
                        public boolean onTouch(View v, MotionEvent event) {
                            return true;
                        }
                    });
                    flag[0] =1;
                    buttonPaintBoardScrollState.setText("글씨쓰기모드-스크롤 비활성화");
                }
                else{
                    // Enable Scrolling by removing the OnTouchListner
                    totalPaintBoardScrollView.setOnTouchListener(null);
                    flag[0]=0;
                    buttonPaintBoardScrollState.setText("글씨쓰기모드나감-스크롤 활성화");
                }
                
                return true;
            }
        });*/

        Button buttonPaintBoardEraseState = rootView.findViewById(R.id.buttonPaintBoardEraseState);
        TextView textLineWidth=rootView.findViewById(R.id.textLineWidth);
        final int[] flag = {0};
        buttonPaintBoardEraseState.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (flag[0] == 0) {

                    flag[0] = 1;
                    paintBoard.setColor(Color.WHITE);
                    textLineWidth.setText("지우개 굵기:");
                    //시크바 최대값 자바코드 설정
                    seekBarLineWidth.setMax(100);
                    buttonPaintBoardEraseState.setText("지우개 모드-OFF하기");
                } else {

                    flag[0] = 0;
                    paintBoard.setColor(currentColor);
                    textLineWidth.setText("선 굵기:");
                    //시크바 최대값 자바코드 설정
                    seekBarLineWidth.setMax(10);
                    buttonPaintBoardEraseState.setText("지우개 모드-ON하기");
                }
            }

        });


        Button buttonBitmapToImage= rootView.findViewById(R.id.buttonBitmapToImage);

        buttonBitmapToImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //클릭한 시점에 현재 비트맵을 가져와야한다. 다른곳에 이코드쓰면 초기에 하얀 비트맵만 가져온다.
                drawBitmap= paintBoard.getBitmap();
                bitmapToImageChange(v);
            }
        });


    }

    public void bitmapToImageChange(View view){
        //Q 버전 이상일 경우. (안드로이드 10, API 29 이상일 경우)
        if(Build.VERSION.SDK_INT>= Build.VERSION_CODES.Q){
            String[] permission={
                    Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE
            };
            int checkWritePermission= ContextCompat.checkSelfPermission(context,android.Manifest.permission.WRITE_EXTERNAL_STORAGE);

            if(checkWritePermission== PackageManager.PERMISSION_GRANTED){
                saveImageOnAboveAndroidQ(drawBitmap);
                Toast.makeText(context,"이미지 저장이 완료되었습니다.",Toast.LENGTH_SHORT).show();
            }
            else{
                int requestExternalStorageCode=1;
                ActivityCompat.requestPermissions(mainActivity,permission,requestExternalStorageCode);
            }

        }
        //Q버전 이하일 경우, 저장소 권한을 얻어온다.
        //위험권한 여부 허용 확인후 위험권한 부여 요청하기
        else{
            String[] permission={
                    Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE
            };
            int checkWritePermission= ContextCompat.checkSelfPermission(context,android.Manifest.permission.WRITE_EXTERNAL_STORAGE);

            if(checkWritePermission== PackageManager.PERMISSION_GRANTED){
                saveImageOnUnderAndroidQ(drawBitmap);
                Toast.makeText(context,"이미지 저장이 완료되었습니다.",Toast.LENGTH_SHORT).show();
            }
            else{
                int requestExternalStorageCode=1;
                ActivityCompat.requestPermissions(mainActivity,permission,requestExternalStorageCode);
            }
        }
    }

    private void saveImageOnAboveAndroidQ(Bitmap bitmap) {
        //파일 이름 현재시간.png
        String fileName=System.currentTimeMillis()+".png";
        /*
         * ContentValues() 객체 생성.
         * ContentValues는 ContentResolver가 처리할 수 있는 값을 저장해둘 목적으로 사용된다.
         * */
        ContentValues contentValues= new ContentValues();
        // 경로 설정
        contentValues.put(MediaStore.Images.Media.RELATIVE_PATH, "DCIM/AskMajor_saveBitmapToImage");
        // 파일이름을 put해준다.
        contentValues.put(MediaStore.Images.Media.DISPLAY_NAME, fileName);
        contentValues.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
        // 현재 is_pending 상태임을 만들어준다.
        // 다른 곳에서 이 데이터를 요구하면 무시하라는 의미로, 해당 저장소를 독점할 수 있다.
        contentValues.put(MediaStore.Images.Media.IS_PENDING, 1);

        // 이미지를 저장할 uri를 미리 설정해놓는다.
        android.net.Uri uri = mainActivity.getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues);
        try{
            if(uri!=null){
                // write 모드로 file을 open한다.
                android.os.ParcelFileDescriptor parcelFileDescriptor= mainActivity.getContentResolver().openFileDescriptor(uri,"w",null);
                if(parcelFileDescriptor!=null){
                    FileOutputStream fileOutputStream=new FileOutputStream(parcelFileDescriptor.getFileDescriptor());
                    //비트맵을 FileOutputStream를 통해 compress한다.
                    bitmap.compress(Bitmap.CompressFormat.PNG,100,fileOutputStream);
                    fileOutputStream.close();

                    contentValues.clear();
                    // 저장소 독점을 해제한다.
                    contentValues.put(MediaStore.Images.Media.IS_PENDING,0);
                    //resolver는 activity에서 받는다.
                    mainActivity.getContentResolver().update(uri,contentValues,null,null);
                }
            }

        } catch(FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void saveImageOnUnderAndroidQ(Bitmap bitmap){
        String fileName=System.currentTimeMillis()+".png";
        String externalStorage= Environment.getExternalStorageDirectory().getAbsolutePath();
        String path="$externalStorage/DCIM/AskMajor_saveBitmapToImage";
        File dir= new File(path);

        if(dir.exists()==false){
            //폴더 없을경우 폴더 생성
            dir.mkdirs();
        }

        try{
            File fileItem= new File("$dir/$fileName");
            //0kb 파일 생성
            fileItem.createNewFile();

            //파일 아웃풋 스트림
            FileOutputStream fileOutputStream= new FileOutputStream(fileItem);

            //파일 아웃풋 스트림 객체를 통해서 Bitmap 압축
            bitmap.compress(Bitmap.CompressFormat.PNG,100,fileOutputStream);

            //파일 아웃풋 스트림 객체 close
            fileOutputStream.close();

            // 브로드캐스트 수신자에게 파일 미디어 스캔 액션 요청. 그리고 데이터로 추가된 파일에 Uri를 넘겨준다. 파일을 uri로 변경
            mainActivity.sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.fromFile(fileItem)));
        } catch(FileNotFoundException e){
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        } catch(Exception e){
            e.printStackTrace();
        }
    }
    @Override
    public void onStart () {
        super.onStart();
    }

}