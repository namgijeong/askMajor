package com.example.askmajor_v5;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;


public class PaintBoardFragment extends Fragment {

    //스피너 아이템 목록
    String[] spinnerItems={"빨강","초록","파랑","검정","노랑","자홍색"};
    String selectedSpinnerItems;
    //activity에 추가할때 호출되어 액티비티를 받아오기 위해
    Context context;
    MainActivity mainActivity;

    //inflate한 전체뷰
    View rootView;
    //프래그먼트 위에 올려줄 뷰
    PaintBoard paintBoard;

    //프래그먼트 위에 올려줄 뷰가 붙여질 위치를 정해주기 위한 뷰
    LinearLayout attachPaintBoard;


    //프래그먼트가 붙여질 부모 뷰 -> viewgroup container
    //ViewGroup container;


  public PaintBoardFragment() {
        // Required empty public constructor
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.context=context;
        mainActivity = (MainActivity) context;
    }

    @Override
    public void onDetach() {
        super.onDetach();
        //이렇게하는건 작동안된다
        //container.removeView(paintBoard);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        rootView=inflater.inflate(R.layout.fragment_paint_board, container, false);
        attachPaintBoard= rootView.findViewById(R.id.attchLayoutPaintBoard);

        paintBoard=new PaintBoard(context);

        attachPaintBoard.addView(paintBoard);

        //프래그먼트가 붙여질 부모 뷰 -> viewgroup container
        //이렇게하는건 작동안된다
        //this.container=container;
        //container.addView(paintBoard);


        return rootView;
    }

    @Override
    public void onViewCreated(final View view, Bundle savedInstanceState){

        SeekBar seekBarLineWidth=rootView.findViewById(R.id.seekBarLineWidth);
        TextView  textLineWidthValue=rootView.findViewById(R.id.textLineWidthValue);
        seekBarLineWidth.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                textLineWidthValue.setText(""+progress);
                paintBoard.setStrokeWidth((float)progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        Spinner spinnerLineColor= rootView.findViewById(R.id.spinnerLineColorSelect);

        ArrayAdapter<String> currentJobAdapter = new ArrayAdapter<String>(
                context,android.R.layout.simple_spinner_item,spinnerItems
        );

        currentJobAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spinnerLineColor.setAdapter(currentJobAdapter);

        spinnerLineColor.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedSpinnerItems=spinnerItems[position];
                if(selectedSpinnerItems.equals("빨강")){
                    //Color.Black이 int형
                    paintBoard.setColor(Color.RED);
                }
                else if(selectedSpinnerItems.equals("초록")){
                    //Color.Black이 int형
                    paintBoard.setColor(Color.GREEN);
                }
                else if(selectedSpinnerItems.equals("파랑")){
                    //Color.Black이 int형
                    paintBoard.setColor(Color.BLUE);
                }
                else if(selectedSpinnerItems.equals("검정")){
                    //Color.Black이 int형
                    paintBoard.setColor(Color.BLACK);
                }
                else if(selectedSpinnerItems.equals("노랑")){
                    //Color.Black이 int형
                    paintBoard.setColor(Color.YELLOW);
                }
                else if(selectedSpinnerItems.equals("자홍색")){
                    //Color.Black이 int형
                    paintBoard.setColor(Color.MAGENTA);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        // Get the ScrollView
        /*final ScrollView totalPaintBoardScrollView = (ScrollView) rootView.findViewById(R.id.totalPaintBoardScrollView);
        Button buttonPaintBoardScrollState=rootView.findViewById(R.id.buttonPaintBoardScrollState);
        final int[] flag = {0};
        
        buttonPaintBoardScrollState.setOnTouchListener(new View.OnTouchListener(){

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(flag[0] ==0){
                    // Disable Scrolling by setting up an OnTouchListener to do nothing
                    totalPaintBoardScrollView.setOnTouchListener( new View.OnTouchListener(){
                        @Override
                        public boolean onTouch(View v, MotionEvent event) {
                            return true;
                        }
                    });
                    flag[0] =1;
                    buttonPaintBoardScrollState.setText("글씨쓰기모드-스크롤 비활성화");
                }
                else{
                    // Enable Scrolling by removing the OnTouchListner
                    totalPaintBoardScrollView.setOnTouchListener(null);
                    flag[0]=0;
                    buttonPaintBoardScrollState.setText("글씨쓰기모드나감-스크롤 활성화");
                }
                
                return true;
            }
        });*/
        

    }


    @Override
    public void onStart() {
        super.onStart();
    }

}